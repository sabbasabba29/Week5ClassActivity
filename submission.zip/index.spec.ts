
import { StandardCalculatorModel } from './index';

describe('week5-creational-DP', (): void => {

  describe('CalculatorModel', (): void => {

    it('CalculatorModel exists', (): void => {

      expect(StandardCalculatorModel).toBeDefined();

    });

  });

});
